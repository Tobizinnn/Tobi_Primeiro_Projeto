import tkinter as tk
from tkinter import messagebox
import random
import os

# ============================================================
# ÁUDIO
# ============================================================

try:

    import pygame

    pygame.mixer.pre_init(
        44100,
        -16,
        2,
        512
    )

    pygame.mixer.init()

    AUDIO_OK = True

except Exception as erro:

    AUDIO_OK = False

    print(
        "Erro ao iniciar o áudio:",
        erro
    )


PASTA_JOGO = os.path.dirname(
    os.path.abspath(__file__)
)

PASTA_SONS = os.path.join(
    PASTA_JOGO,
    "sons"
)

# A música de fundo é a primeira que existir nesta lista.
# Para usar outra música, coloque o arquivo na pasta "sons"
# e ponha o nome dele aqui na frente.
ARQUIVOS_MUSICA = [
    os.path.join(PASTA_SONS, "musica_fundo.wav"),
    os.path.join(PASTA_JOGO, "on_on.mp3"),
]

VOLUME_MUSICA = 0.35
VOLUME_EFEITOS = 0.70

SONS = {}


def carregar_sons():

    if not AUDIO_OK:
        return

    nomes = [
        "acerto",
        "erro",
        "esgotado",
        "clique",
        "tick",
        "dica",
        "relogio",
        "comecar",
        "vitoria",
        "fim"
    ]

    for nome in nomes:

        caminho = os.path.join(
            PASTA_SONS,
            nome + ".wav"
        )

        if not os.path.exists(caminho):
            continue

        try:

            som = pygame.mixer.Sound(
                caminho
            )

            som.set_volume(
                VOLUME_EFEITOS
            )

            SONS[nome] = som

        except Exception as erro:

            print(
                f"Erro ao carregar o som {nome}:",
                erro
            )


def tocar_som(nome):

    if not AUDIO_OK:
        return

    som = SONS.get(nome)

    if som is None:
        return

    try:

        som.play()

    except Exception:
        pass


def iniciar_musica():

    if not AUDIO_OK:
        return

    try:

        # se já está tocando, não reinicia a música
        if pygame.mixer.music.get_busy():
            return

    except Exception:
        pass

    arquivo = None

    for caminho in ARQUIVOS_MUSICA:

        if os.path.exists(caminho):

            arquivo = caminho

            break

    if arquivo is None:

        print(
            "Música não encontrada. "
            "Coloque musica_fundo.wav "
            "na pasta 'sons'."
        )

        return

    try:

        pygame.mixer.music.load(
            arquivo
        )

        pygame.mixer.music.set_volume(
            VOLUME_MUSICA
        )

        pygame.mixer.music.play(
            loops=-1
        )

    except Exception as erro:

        print(
            "Erro ao tocar música:",
            erro
        )


def parar_musica():

    if not AUDIO_OK:
        return

    try:

        pygame.mixer.music.stop()

    except Exception:
        pass


def tocar_som_acerto():

    tocar_som("acerto")


carregar_sons()


# ============================================================
# PERGUNTAS
# ============================================================

PERGUNTAS = {

    "História": {

        "1º Ano": [
            ("O que é uma certidão de nascimento?",
             ["Um documento com o nome e a data em que nascemos",
              "Um brinquedo",
              "Uma receita de bolo",
              "Um tipo de roupa"],
             0),

            ("Quem são os avós de uma criança?",
             ["Os pais do pai ou da mãe dela",
              "Os colegas da escola",
              "Os vizinhos da rua",
              "Os professores"],
             0),

            ("O que usamos para saber os dias, as semanas e os meses?",
             ["O calendário",
              "O espelho",
              "O cobertor",
              "O garfo"],
             0),

            ("Qual objeto ajuda a guardar as lembranças da família?",
             ["Um álbum de fotografias",
              "Uma colher",
              "Uma vassoura",
              "Um chinelo"],
             0),

            ("Quantos dias tem uma semana?",
             ["7",
              "5",
              "10",
              "12"],
             0),

            ("Qual destas palavras fala de um tempo que já passou?",
             ["Ontem",
              "Amanhã",
              "Daqui a pouco",
              "Depois"],
             0),

            ("Para que serve o nosso nome?",
             ["Para identificar cada pessoa",
              "Para pesar objetos",
              "Para medir o tempo",
              "Para cozinhar"],
             0),

            ("Qual lugar é feito para aprender e brincar com os colegas?",
             ["A escola",
              "O mercado",
              "O hospital",
              "A padaria"],
             0),

            ("O que acontece com uma pessoa com o passar dos anos?",
             ["Ela cresce e vai mudando",
              "Ela fica sempre igual",
              "Ela volta a ser bebê",
              "Ela encolhe todo ano"],
             0),

            ("Quem ensina as crianças na escola?",
             ["O professor",
              "O goleiro",
              "O padeiro",
              "O motorista"],
             0),
        ],

        "2º Ano": [
            ("O que é uma comunidade?",
             ["Um grupo de pessoas que vivem e convivem num mesmo lugar",
              "Um tipo de animal",
              "Uma ferramenta",
              "Uma estação do ano"],
             0),

            ("Qual profissional combate incêndios?",
             ["O bombeiro",
              "O padeiro",
              "O pintor",
              "O cozinheiro"],
             0),

            ("Antigamente, qual meio era muito usado para enviar notícias para longe?",
             ["A carta",
              "O aplicativo de mensagem",
              "O e-mail",
              "A videochamada"],
             0),

            ("Qual destes brinquedos era comum nas brincadeiras de rua de antigamente?",
             ["O pião",
              "O tablet",
              "O drone",
              "O robô de controle remoto"],
             0),

            ("Quantos meses tem um ano?",
             ["12",
              "10",
              "7",
              "24"],
             0),

            ("Qual instrumento mostra as horas e os minutos?",
             ["O relógio",
              "A régua",
              "A balança",
              "O termômetro"],
             0),

            ("Para que servem as regras de convivência?",
             ["Para todos viverem bem juntos",
              "Para ninguém brincar",
              "Para acabar com a escola",
              "Para esconder as coisas"],
             0),

            ("Quem planta e colhe os alimentos no campo?",
             ["O agricultor",
              "O professor",
              "O motorista",
              "O dentista"],
             0),

            ("Qual lugar guarda livros para leitura e empréstimo?",
             ["A biblioteca",
              "A padaria",
              "A farmácia",
              "A quadra"],
             0),

            ("Como chamamos as pessoas que moram juntas e cuidam umas das outras?",
             ["Família",
              "Time",
              "Turma",
              "Fila"],
             0),
        ],

        "3º Ano": [
            ("Onde costuma haver mais plantações e criação de animais?",
             ["No campo",
              "No centro da cidade",
              "Dentro de um shopping",
              "No metrô"],
             0),

            ("Quem administra uma cidade (município) no Brasil?",
             ["O prefeito",
              "O presidente",
              "O governador",
              "O ministro"],
             0),

            ("Que povos já viviam no território do Brasil antes da chegada dos portugueses?",
             ["Os povos indígenas",
              "Os romanos",
              "Os egípcios",
              "Os vikings"],
             0),

            ("O que é patrimônio histórico?",
             ["Bens e lugares importantes que contam a história de um povo",
              "Dinheiro guardado no banco",
              "Um jogo de tabuleiro",
              "Uma máquina nova"],
             0),

            ("Qual destes é um meio de transporte coletivo da cidade?",
             ["O ônibus",
              "O skate",
              "O patinete",
              "A bicicleta"],
             0),

            ("Qual profissional cuida da saúde das pessoas no hospital?",
             ["O médico",
              "O pedreiro",
              "O padeiro",
              "O jardineiro"],
             0),

            ("O que é um museu?",
             ["Um lugar que guarda e mostra objetos históricos",
              "Um lugar onde se vendem frutas",
              "Um lugar onde se lavam carros",
              "Um lugar para consertar sapatos"],
             0),

            ("As festas populares, como as festas juninas, fazem parte de quê?",
             ["Da cultura e das tradições de um povo",
              "Da previsão do tempo",
              "Da matemática",
              "Das regras de trânsito"],
             0),

            ("O que é uma tradição?",
             ["Um costume passado de geração em geração",
              "Uma moeda antiga",
              "Um tipo de nuvem",
              "Um jogo eletrônico"],
             0),

            ("Qual profissional constrói casas e prédios?",
             ["O pedreiro",
              "O cantor",
              "O goleiro",
              "O cozinheiro"],
             0),
        ],

        "4º Ano": [
            ("O que significa dizer que um povo era nômade?",
             ["Que mudava de lugar com frequência",
              "Que morava sempre no mesmo lugar",
              "Que vivia só em castelos",
              "Que vivia debaixo d'água"],
             0),

            ("O que é migração?",
             ["O deslocamento de pessoas de um lugar para outro",
              "A construção de uma casa",
              "A plantação de árvores",
              "A pesca de peixes"],
             0),

            ("Como é chamado um povo que fixa moradia e cultiva alimentos?",
             ["Sedentário",
              "Nômade",
              "Navegante",
              "Caçador"],
             0),

            ("Quais povos imigrantes vieram em grande número para o Sul do Brasil no século XIX?",
             ["Alemães e italianos",
              "Egípcios e gregos",
              "Vikings e persas",
              "Maias e astecas"],
             0),

            ("De onde foram trazidas à força as pessoas escravizadas que trabalharam no Brasil colonial?",
             ["Da África",
              "Da Antártida",
              "Da Oceania",
              "Da Groenlândia"],
             0),

            ("Qual invenção permitiu aos seres humanos se fixarem em um lugar?",
             ["A agricultura",
              "O telefone",
              "O cinema",
              "A eletricidade"],
             0),

            ("O que é cidadania?",
             ["Ter direitos e deveres na sociedade",
              "Ser dono de uma empresa",
              "Morar em outro país",
              "Ter muito dinheiro"],
             0),

            ("Por que os rios foram importantes para o surgimento das primeiras cidades?",
             ["Davam água, alimento e transporte",
              "Serviam para guardar tesouros",
              "Impediam as pessoas de plantar",
              "Geravam eletricidade desde 1500"],
             0),

            ("O que é um documento histórico?",
             ["Uma fonte que ajuda a conhecer o passado",
              "Um brinquedo novo",
              "Uma música da moda",
              "Um jogo de futebol"],
             0),

            ("Qual povo indígena é originário do Alto Vale do Itajaí, em Santa Catarina?",
             ["Xokleng",
              "Yanomami",
              "Kayapó",
              "Bororo"],
             0),
        ],

        "5º Ano": [
            ("Por que a invenção da escrita foi tão importante?",
             ["Permitiu registrar e guardar informações",
              "Serviu apenas para enfeitar casas",
              "Acabou com a fala",
              "Foi criada no século XXI"],
             0),

            ("Qual documento garante os direitos e deveres dos brasileiros?",
             ["A Constituição",
              "O calendário",
              "A bula de remédio",
              "O mapa-múndi"],
             0),

            ("O que é democracia?",
             ["Governo em que o povo participa das decisões",
              "Governo de um só rei",
              "Governo sem leis",
              "Governo apenas dos militares"],
             0),

            ("O que são direitos humanos?",
             ["Direitos que todas as pessoas têm por serem humanas",
              "Regras só para adultos",
              "Leis de um país antigo",
              "Direitos de quem tem dinheiro"],
             0),

            ("Como se chama o dia em que os brasileiros escolhem seus governantes?",
             ["Dia de eleição",
              "Dia do recreio",
              "Dia da feira",
              "Dia do aniversário"],
             0),

            ("Qual invenção facilitou a produção de livros e a divulgação do conhecimento?",
             ["A prensa de Gutenberg",
              "O telefone",
              "A bicicleta",
              "O relógio de sol"],
             0),

            ("Qual lei brasileira protege as crianças e os adolescentes?",
             ["O Estatuto da Criança e do Adolescente (ECA)",
              "O Código de Trânsito",
              "O Código Florestal",
              "A Lei do Inquilinato"],
             0),

            ("Qual destes alimentos tem origem indígena?",
             ["A mandioca",
              "O trigo",
              "A azeitona",
              "A uva"],
             0),

            ("Quais povos contribuíram para formar a população e a cultura do Brasil?",
             ["Indígenas, africanos e europeus",
              "Somente os vikings",
              "Somente os romanos",
              "Somente os egípcios"],
             0),

            ("Qual destas é uma manifestação cultural imaterial do Brasil?",
             ["O samba",
              "Um prédio antigo",
              "Uma ponte",
              "Uma estátua"],
             0),
        ],

        "6º Ano": [
            ("Como é chamado o período que vai da invenção da escrita até a queda do Império Romano do Ocidente (476 d.C.)?",
             ["Antiguidade",
              "Pré-História",
              "Idade Moderna",
              "Idade Contemporânea"],
             0),

            ("O que marca o fim da Pré-História?",
             ["A invenção da escrita",
              "A invenção da internet",
              "A Revolução Francesa",
              "O descobrimento do Brasil"],
             0),

            ("Qual rio foi fundamental para a civilização do Egito Antigo?",
             ["O Nilo",
              "O Amazonas",
              "O Tâmisa",
              "O Sena"],
             0),

            ("Como se chamava o governante do Egito Antigo?",
             ["Faraó",
              "Imperador",
              "Sultão",
              "Czar"],
             0),

            ("Qual civilização antiga criou a democracia em Atenas?",
             ["Os gregos",
              "Os persas",
              "Os egípcios",
              "Os fenícios"],
             0),

            ("Qual cidade deu origem ao Império Romano?",
             ["Roma",
              "Atenas",
              "Esparta",
              "Cartago"],
             0),

            ("Qual povo da Mesopotâmia criou a escrita cuneiforme?",
             ["Os sumérios",
              "Os vikings",
              "Os maias",
              "Os astecas"],
             0),

            ("Qual povo antigo é famoso por ter espalhado o alfabeto pelo Mediterrâneo?",
             ["Os fenícios",
              "Os incas",
              "Os celtas",
              "Os hunos"],
             0),

            ("Onde aconteceram os primeiros Jogos Olímpicos da Antiguidade?",
             ["Em Olímpia, na Grécia",
              "Em Roma",
              "No Cairo",
              "Na Babilônia"],
             0),

            ("O que era o Coliseu, em Roma?",
             ["Um grande anfiteatro para espetáculos",
              "Um templo egípcio",
              "Uma biblioteca grega",
              "Um palácio persa"],
             0),
        ],

        "7º Ano": [
            ("Qual período da história europeia veio depois da Antiguidade?",
             ["Idade Média",
              "Idade Contemporânea",
              "Pré-História",
              "Idade da Pedra"],
             0),

            ("Qual era o sistema social e econômico predominante na Europa medieval?",
             ["O feudalismo",
              "O capitalismo industrial",
              "O socialismo",
              "A democracia direta"],
             0),

            ("Em que ano Pedro Álvares Cabral chegou ao Brasil?",
             ["1500",
              "1492",
              "1822",
              "1889"],
             0),

            ("Qual movimento valorizou a arte, a ciência e o ser humano na Europa a partir do século XIV?",
             ["O Renascimento",
              "O Feudalismo",
              "O Absolutismo",
              "O Imperialismo"],
             0),

            ("Qual povo construiu a cidade de Machu Picchu?",
             ["Os incas",
              "Os astecas",
              "Os maias",
              "Os egípcios"],
             0),

            ("Qual foi o primeiro produto explorado pelos portugueses no Brasil?",
             ["O pau-brasil",
              "O café",
              "O ouro",
              "A borracha"],
             0),

            ("Como se chamou a divisão do Brasil colonial em grandes faixas de terra entregues a donatários?",
             ["Capitanias hereditárias",
              "Províncias",
              "Estados",
              "Territórios federais"],
             0),

            ("Qual atividade econômica dominou o Nordeste colonial nos séculos XVI e XVII?",
             ["O cultivo de cana-de-açúcar",
              "A extração de petróleo",
              "A indústria de carros",
              "A mineração de diamantes"],
             0),

            ("Qual navegador iniciou a primeira viagem de volta ao mundo, em 1519?",
             ["Fernão de Magalhães",
              "Cristóvão Colombo",
              "Vasco da Gama",
              "Pedro Álvares Cabral"],
             0),

            ("Qual povo da América construiu a cidade de Tenochtitlán?",
             ["Os astecas",
              "Os incas",
              "Os romanos",
              "Os tupis"],
             0),
        ],

        "8º Ano": [
            ("Qual acontecimento é considerado o marco inicial da Revolução Francesa, em 1789?",
             ["A Queda da Bastilha",
              "A Proclamação da República",
              "A Abolição da escravidão",
              "A chegada de Cabral"],
             0),

            ("Qual era o lema da Revolução Francesa?",
             ["Liberdade, Igualdade e Fraternidade",
              "Ordem e Progresso",
              "Deus, Pátria e Família",
              "Paz e Amor"],
             0),

            ("Em que país começou a Revolução Industrial?",
             ["Inglaterra",
              "Brasil",
              "Egito",
              "China"],
             0),

            ("Em que ano ocorreu a Independência do Brasil?",
             ["1822",
              "1500",
              "1889",
              "1888"],
             0),

            ("Quem foi o primeiro imperador do Brasil?",
             ["Dom Pedro I",
              "Dom Pedro II",
              "Tiradentes",
              "Deodoro da Fonseca"],
             0),

            ("Qual lei, de 1888, aboliu a escravidão no Brasil?",
             ["A Lei Áurea",
              "A Lei do Ventre Livre",
              "A Lei Eusébio de Queirós",
              "A Lei dos Sexagenários"],
             0),

            ("Qual movimento do século XVIII defendia a razão e criticava o absolutismo?",
             ["O Iluminismo",
              "O Feudalismo",
              "O Mercantilismo",
              "O Nazismo"],
             0),

            ("Qual país conquistou a independência em 1776 e formou uma república?",
             ["Estados Unidos",
              "Brasil",
              "Argentina",
              "México"],
             0),

            ("Quem liderou a independência de países como Venezuela e Colômbia?",
             ["Simón Bolívar",
              "Dom Pedro I",
              "Napoleão",
              "Tiradentes"],
             0),

            ("O que marcou a Revolução Industrial?",
             ["O uso de máquinas e de fábricas na produção",
              "A volta ao feudalismo",
              "O fim do comércio",
              "A descoberta da escrita"],
             0),
        ],

        "9º Ano": [
            ("Em que ano foi proclamada a República no Brasil?",
             ["1889",
              "1822",
              "1930",
              "1964"],
             0),

            ("Quem proclamou a República no Brasil?",
             ["Marechal Deodoro da Fonseca",
              "Dom Pedro II",
              "Getúlio Vargas",
              "Juscelino Kubitschek"],
             0),

            ("Em que ano começou a Primeira Guerra Mundial?",
             ["1914",
              "1939",
              "1945",
              "1929"],
             0),

            ("Em que ano terminou a Segunda Guerra Mundial?",
             ["1945",
              "1939",
              "1918",
              "1950"],
             0),

            ("Qual organização foi criada em 1945 para promover a paz entre as nações?",
             ["ONU",
              "OTAN",
              "Mercosul",
              "FIFA"],
             0),

            ("Quem governou o Brasil durante a Era Vargas?",
             ["Getúlio Vargas",
              "Juscelino Kubitschek",
              "Dom Pedro II",
              "Fernando Henrique Cardoso"],
             0),

            ("Como ficou conhecido o período de tensão entre EUA e URSS após a Segunda Guerra?",
             ["Guerra Fria",
              "Guerra dos Cem Anos",
              "Guerra do Paraguai",
              "Guerra de Troia"],
             0),

            ("Em que ano começou a ditadura militar no Brasil?",
             ["1964",
              "1945",
              "1985",
              "1930"],
             0),

            ("Qual presidente construiu Brasília e inaugurou a capital em 1960?",
             ["Juscelino Kubitschek",
              "Getúlio Vargas",
              "Jânio Quadros",
              "João Goulart"],
             0),

            ("Qual movimento popular pediu eleições diretas para presidente em 1984?",
             ["Diretas Já",
              "Tropicália",
              "Cangaço",
              "Inconfidência Mineira"],
             0),
        ],
    },


    "Geografia": {

        "1º Ano": [
            ("Qual lugar é onde a gente mora com a família?",
             ["A casa",
              "A escola",
              "A praia",
              "O mercado"],
             0),

            ("Quando o Sol aparece no céu, é...",
             ["Dia",
              "Noite",
              "Madrugada",
              "Inverno"],
             0),

            ("Qual destes é um meio de transporte?",
             ["O ônibus",
              "A colher",
              "A cama",
              "O sapato"],
             0),

            ("Qual parte da casa é usada para cozinhar?",
             ["A cozinha",
              "O banheiro",
              "O quarto",
              "A sala"],
             0),

            ("Qual destes é um elemento da natureza?",
             ["Uma árvore",
              "Um carro",
              "Um prédio",
              "Uma bola"],
             0),

            ("O que usamos para ver onde ficam os lugares?",
             ["O mapa",
              "A colher",
              "O sapato",
              "O lápis"],
             0),

            ("O que podemos ver no céu à noite?",
             ["A Lua e as estrelas",
              "O arco-íris",
              "O Sol forte",
              "Um avião de papel"],
             0),

            ("Qual é o lado oposto da direita?",
             ["A esquerda",
              "A frente",
              "O alto",
              "O dentro"],
             0),

            ("Qual lugar público serve para brincar e passear?",
             ["A praça",
              "A cozinha",
              "O quarto",
              "A garagem"],
             0),

            ("Qual elemento da natureza vem das nuvens e molha o chão?",
             ["A chuva",
              "O vento",
              "A areia",
              "O fogo"],
             0),
        ],

        "2º Ano": [
            ("Em que direção o Sol nasce?",
             ["Leste",
              "Oeste",
              "Norte",
              "Sul"],
             0),

            ("Qual destes é um meio de comunicação?",
             ["A televisão",
              "A bicicleta",
              "O prédio",
              "A ponte"],
             0),

            ("O que é um bairro?",
             ["Uma parte da cidade onde as pessoas moram e convivem",
              "Um tipo de rio",
              "Um tipo de montanha",
              "Um país"],
             0),

            ("O que é uma paisagem?",
             ["Tudo o que conseguimos ver em um lugar",
              "Um tipo de moeda",
              "Um instrumento musical",
              "Um alimento"],
             0),

            ("Qual destas é uma paisagem natural?",
             ["Uma floresta",
              "Um shopping",
              "Uma estrada asfaltada",
              "Um prédio"],
             0),

            ("Qual meio de transporte anda sobre trilhos?",
             ["O trem",
              "O barco",
              "O avião",
              "A bicicleta"],
             0),

            ("Qual meio de transporte viaja pela água?",
             ["O navio",
              "O carro",
              "O trem",
              "A moto"],
             0),

            ("Para que serve um semáforo?",
             ["Organizar o trânsito",
              "Medir a chuva",
              "Guardar água",
              "Iluminar a casa"],
             0),

            ("Qual destes lugares fica no campo (zona rural)?",
             ["Uma fazenda",
              "Um shopping",
              "O metrô",
              "Um arranha-céu"],
             0),

            ("Qual destes serviços é oferecido em um posto de saúde?",
             ["Atendimento médico e vacinas",
              "Venda de roupas",
              "Conserto de carros",
              "Aulas de dança"],
             0),
        ],

        "3º Ano": [
            ("Antes de chegar às casas, a água é tratada em uma...",
             ["Estação de tratamento",
              "Fábrica de brinquedos",
              "Usina de sorvete",
              "Agência de turismo"],
             0),

            ("Para onde deve ir o lixo reciclável, como papel, vidro e plástico?",
             ["Para a coleta seletiva",
              "Para os rios",
              "Para a rua",
              "Para a floresta"],
             0),

            ("Qual destes é um recurso natural?",
             ["A água",
              "O computador",
              "O carro",
              "O brinquedo"],
             0),

            ("O que é a zona rural?",
             ["A área do campo, com plantações e criação de animais",
              "Uma área só de prédios",
              "Um tipo de mapa",
              "Um país"],
             0),

            ("O que é a zona urbana?",
             ["A área da cidade, com ruas, prédios e comércio",
              "Uma plantação",
              "Uma floresta",
              "Um rio"],
             0),

            ("Qual destas atitudes ajuda a economizar água?",
             ["Fechar a torneira ao escovar os dentes",
              "Deixar a mangueira ligada",
              "Tomar banhos demorados",
              "Lavar a calçada todo dia"],
             0),

            ("Qual destes recursos vem das árvores?",
             ["A madeira",
              "O petróleo",
              "O ferro",
              "A areia"],
             0),

            ("O que é um mapa?",
             ["Uma representação de um lugar visto de cima",
              "Um livro de receitas",
              "Um instrumento musical",
              "Uma roupa"],
             0),

            ("O que é reciclar?",
             ["Transformar materiais usados em novos produtos",
              "Jogar tudo fora",
              "Queimar o lixo",
              "Esconder o lixo"],
             0),

            ("O que causa a poluição dos rios?",
             ["Jogar lixo e esgoto neles",
              "Plantar árvores nas margens",
              "Cuidar das nascentes",
              "Limpar as margens"],
             0),
        ],

        "4º Ano": [
            ("Quais são os quatro pontos cardeais?",
             ["Norte, Sul, Leste e Oeste",
              "Cima, baixo, frente e trás",
              "Centro, borda, meio e lado",
              "Esquerda, direita, frente e atrás"],
             0),

            ("Qual instrumento indica o Norte?",
             ["A bússola",
              "O termômetro",
              "A balança",
              "O relógio"],
             0),

            ("Quantos estados tem o Brasil?",
             ["26 estados e o Distrito Federal",
              "20 estados",
              "30 estados",
              "12 estados"],
             0),

            ("Qual é a capital do Brasil?",
             ["Brasília",
              "Rio de Janeiro",
              "São Paulo",
              "Salvador"],
             0),

            ("Qual é a capital de Santa Catarina?",
             ["Florianópolis",
              "Joinville",
              "Blumenau",
              "Itajaí"],
             0),

            ("Quantas regiões tem o Brasil?",
             ["5",
              "3",
              "7",
              "9"],
             0),

            ("Qual é o maior rio do Brasil em volume de água?",
             ["Rio Amazonas",
              "Rio São Francisco",
              "Rio Tietê",
              "Rio Paraná"],
             0),

            ("O que é o relevo?",
             ["As formas da superfície da Terra, como montanhas e planícies",
              "A quantidade de chuva",
              "A temperatura do ar",
              "A velocidade do vento"],
             0),

            ("O que é uma fronteira?",
             ["A linha que separa dois territórios",
              "Um tipo de rio",
              "Uma montanha",
              "Uma praia"],
             0),

            ("Em que região do Brasil fica Santa Catarina?",
             ["Sul",
              "Norte",
              "Nordeste",
              "Centro-Oeste"],
             0),
        ],

        "5º Ano": [
            ("Quais são as cinco regiões do Brasil?",
             ["Norte, Nordeste, Centro-Oeste, Sudeste e Sul",
              "Norte, Sul, Leste, Oeste e Centro",
              "Amazônia, Pampa, Cerrado, Caatinga e Pantanal",
              "Litoral, Sertão, Serra, Vale e Planalto"],
             0),

            ("Qual é a região mais populosa do Brasil?",
             ["Sudeste",
              "Norte",
              "Sul",
              "Centro-Oeste"],
             0),

            ("Qual é o maior estado do Brasil em área?",
             ["Amazonas",
              "Pará",
              "Mato Grosso",
              "Bahia"],
             0),

            ("Qual é o menor estado brasileiro em área?",
             ["Sergipe",
              "Alagoas",
              "Espírito Santo",
              "Rio de Janeiro"],
             0),

            ("O que é êxodo rural?",
             ["A saída de pessoas do campo para a cidade",
              "A volta das pessoas da cidade para o mar",
              "A criação de animais",
              "A plantação de árvores"],
             0),

            ("Qual instituição realiza o Censo, que conta a população brasileira?",
             ["IBGE",
              "INSS",
              "Correios",
              "Anvisa"],
             0),

            ("Qual é o clima predominante no interior do Nordeste, com chuvas irregulares?",
             ["Semiárido",
              "Equatorial",
              "Polar",
              "Subtropical"],
             0),

            ("O que significa desenvolvimento sustentável?",
             ["Usar os recursos sem esgotá-los para as futuras gerações",
              "Usar tudo o mais rápido possível",
              "Parar toda a produção",
              "Proibir as cidades"],
             0),

            ("Qual destas atividades pertence ao setor primário da economia?",
             ["A agricultura",
              "A indústria de carros",
              "O comércio de roupas",
              "O turismo"],
             0),

            ("O que a escala de um mapa indica?",
             ["A relação entre o tamanho real e o desenhado",
              "A cor do mapa",
              "O nome do mapa",
              "O ano de criação do mapa"],
             0),
        ],

        "6º Ano": [
            ("O que é latitude?",
             ["Distância em graus de um ponto até a Linha do Equador",
              "Distância em graus até o Meridiano de Greenwich",
              "Altura em relação ao mar",
              "Profundidade de um oceano"],
             0),

            ("O que é longitude?",
             ["Distância em graus de um ponto até o Meridiano de Greenwich",
              "Distância em graus até o Equador",
              "Altura de uma montanha",
              "Temperatura do ar"],
             0),

            ("Qual movimento da Terra provoca o dia e a noite?",
             ["Rotação",
              "Translação",
              "Erosão",
              "Sedimentação"],
             0),

            ("Qual movimento da Terra, junto com a inclinação do eixo, provoca as estações do ano?",
             ["Translação",
              "Rotação",
              "Erosão",
              "Maré"],
             0),

            ("A camada externa e sólida da Terra, onde vivemos, é a...",
             ["Crosta terrestre",
              "Manto",
              "Núcleo",
              "Atmosfera"],
             0),

            ("Qual linha imaginária divide a Terra em hemisférios Norte e Sul?",
             ["Linha do Equador",
              "Meridiano de Greenwich",
              "Trópico de Capricórnio",
              "Círculo Polar Ártico"],
             0),

            ("Qual é a camada de gases que envolve a Terra?",
             ["Atmosfera",
              "Litosfera",
              "Hidrosfera",
              "Biosfera"],
             0),

            ("O que é clima?",
             ["O padrão do tempo atmosférico de um lugar, observado por muitos anos",
              "A chuva de hoje",
              "A temperatura de agora",
              "O vento da manhã"],
             0),

            ("Qual instrumento mede a temperatura do ar?",
             ["Termômetro",
              "Pluviômetro",
              "Barômetro",
              "Anemômetro"],
             0),

            ("Qual é o maior oceano do planeta?",
             ["Pacífico",
              "Atlântico",
              "Índico",
              "Ártico"],
             0),
        ],

        "7º Ano": [
            ("Qual bioma ocupa a maior parte do território brasileiro?",
             ["Amazônia",
              "Cerrado",
              "Caatinga",
              "Pampa"],
             0),

            ("Qual bioma é exclusivamente brasileiro e típico do sertão nordestino?",
             ["Caatinga",
              "Pantanal",
              "Pampa",
              "Mata Atlântica"],
             0),

            ("Qual bioma brasileiro é a maior planície alagável do mundo?",
             ["Pantanal",
              "Cerrado",
              "Amazônia",
              "Pampa"],
             0),

            ("Qual bioma é chamado de \"berço das águas\", por abrigar nascentes de grandes bacias?",
             ["Cerrado",
              "Caatinga",
              "Pampa",
              "Mata Atlântica"],
             0),

            ("Qual bioma se estende pelo litoral e foi muito devastado pela ocupação humana?",
             ["Mata Atlântica",
              "Pantanal",
              "Caatinga",
              "Amazônia"],
             0),

            ("O que é urbanização?",
             ["O crescimento das cidades e da população urbana",
              "A volta de todos ao campo",
              "A plantação de florestas",
              "O fim das cidades"],
             0),

            ("Qual é a região brasileira mais populosa e industrializada?",
             ["Sudeste",
              "Norte",
              "Centro-Oeste",
              "Sul"],
             0),

            ("Qual é o clima predominante na Amazônia?",
             ["Equatorial",
              "Polar",
              "Semiárido",
              "Temperado"],
             0),

            ("Qual bioma é típico do Rio Grande do Sul, com campos e pastagens?",
             ["Pampa",
              "Caatinga",
              "Amazônia",
              "Cerrado"],
             0),

            ("Qual é a maior bacia hidrográfica do Brasil?",
             ["Bacia Amazônica",
              "Bacia do Rio São Francisco",
              "Bacia do Paraná",
              "Bacia do Uruguai"],
             0),
        ],

        "8º Ano": [
            ("Qual é o maior país da América do Sul em área?",
             ["Brasil",
              "Argentina",
              "Peru",
              "Colômbia"],
             0),

            ("Qual país da América do Norte é o mais populoso?",
             ["Estados Unidos",
              "Canadá",
              "México",
              "Cuba"],
             0),

            ("Qual cordilheira percorre o oeste da América do Sul?",
             ["Cordilheira dos Andes",
              "Himalaia",
              "Alpes",
              "Montes Urais"],
             0),

            ("Qual é o maior deserto quente do mundo, localizado na África?",
             ["Saara",
              "Atacama",
              "Gobi",
              "Kalahari"],
             0),

            ("Qual é o rio mais extenso da África?",
             ["Nilo",
              "Congo",
              "Níger",
              "Zambeze"],
             0),

            ("Qual é o país mais populoso da África?",
             ["Nigéria",
              "Egito",
              "África do Sul",
              "Etiópia"],
             0),

            ("Qual bloco econômico reúne Brasil, Argentina, Paraguai e Uruguai?",
             ["Mercosul",
              "União Europeia",
              "Nafta",
              "Asean"],
             0),

            ("Qual país é o maior produtor de café do mundo?",
             ["Brasil",
              "Colômbia",
              "Vietnã",
              "Etiópia"],
             0),

            ("O que é o IDH?",
             ["Índice de Desenvolvimento Humano",
              "Índice de Defesa Hídrica",
              "Instituto de Dados Históricos",
              "Índice de Distribuição de Habitantes"],
             0),

            ("Qual país africano fala português e foi colônia de Portugal?",
             ["Angola",
              "Egito",
              "Quênia",
              "Nigéria"],
             0),
        ],

        "9º Ano": [
            ("O que é globalização?",
             ["Maior integração econômica, cultural e tecnológica entre os países",
              "Separação dos países por muros",
              "O fim do comércio",
              "A volta ao feudalismo"],
             0),

            ("Qual é o país mais populoso do mundo atualmente?",
             ["Índia",
              "China",
              "Estados Unidos",
              "Brasil"],
             0),

            ("Qual país possui a maior extensão territorial do mundo?",
             ["Rússia",
              "Canadá",
              "China",
              "Estados Unidos"],
             0),

            ("Qual bloco reúne países da Europa e criou uma moeda comum, o euro?",
             ["União Europeia",
              "Mercosul",
              "Nafta",
              "Brics"],
             0),

            ("Qual continente é o mais frio e coberto de gelo?",
             ["Antártida",
              "Europa",
              "Oceania",
              "Ásia"],
             0),

            ("O que significa aquecimento global?",
             ["O aumento da temperatura média do planeta",
              "A chegada do inverno",
              "O resfriamento dos oceanos",
              "A diminuição das chuvas em um dia"],
             0),

            ("Qual gás é o principal responsável pelo agravamento do efeito estufa?",
             ["Dióxido de carbono (CO₂)",
              "Oxigênio (O₂)",
              "Nitrogênio (N₂)",
              "Hélio (He)"],
             0),

            ("Qual país asiático, formado por ilhas, é uma grande potência tecnológica?",
             ["Japão",
              "Mongólia",
              "Nepal",
              "Cazaquistão"],
             0),

            ("Qual organização reúne os países em torno da paz e da cooperação internacional?",
             ["ONU",
              "FIFA",
              "OPEP",
              "OMC"],
             0),

            ("Quais países formavam originalmente o grupo BRIC?",
             ["Brasil, Rússia, Índia e China",
              "Bolívia, Rússia, Irã e Cuba",
              "Bélgica, Reino Unido, Itália e Canadá",
              "Bahamas, Roma, Índia e Cuba"],
             0),
        ],
    },


    "Matemática": {

        "1º Ano": [
            ("Quanto é 3 + 2?",
             ["5",
              "4",
              "6",
              "7"],
             0),

            ("Quanto é 8 - 3?",
             ["5",
              "4",
              "6",
              "3"],
             0),

            ("Qual número vem depois do 9?",
             ["10",
              "8",
              "11",
              "19"],
             0),

            ("Quanto é 6 + 4?",
             ["10",
              "9",
              "11",
              "12"],
             0),

            ("Qual destes números é o maior?",
             ["15",
              "11",
              "9",
              "12"],
             0),

            ("Quantos lados tem um triângulo?",
             ["3",
              "4",
              "5",
              "2"],
             0),

            ("Quanto é 10 - 5?",
             ["5",
              "4",
              "6",
              "10"],
             0),

            ("Qual número vem antes do 5?",
             ["4",
              "6",
              "3",
              "7"],
             0),

            ("Qual forma lembra uma bola?",
             ["Esfera",
              "Cubo",
              "Triângulo",
              "Quadrado"],
             0),

            ("Quanto é 7 + 2?",
             ["9",
              "8",
              "10",
              "7"],
             0),
        ],

        "2º Ano": [
            ("Quanto é 14 + 5?",
             ["19",
              "18",
              "20",
              "17"],
             0),

            ("Quanto é 20 - 8?",
             ["12",
              "11",
              "13",
              "10"],
             0),

            ("Qual é o dobro de 6?",
             ["12",
              "8",
              "10",
              "16"],
             0),

            ("Quantas dezenas há em 30?",
             ["3",
              "1",
              "30",
              "0"],
             0),

            ("Quanto é 25 + 25?",
             ["50",
              "40",
              "45",
              "55"],
             0),

            ("Qual é a metade de 10?",
             ["5",
              "2",
              "4",
              "8"],
             0),

            ("Quantos minutos tem 1 hora?",
             ["60",
              "30",
              "100",
              "24"],
             0),

            ("Quanto é 2 + 2 + 2 + 2?",
             ["8",
              "6",
              "10",
              "4"],
             0),

            ("Quantas unidades tem uma dezena?",
             ["10",
              "1",
              "100",
              "5"],
             0),

            ("Quanto é 50 - 20?",
             ["30",
              "20",
              "40",
              "70"],
             0),
        ],

        "3º Ano": [
            ("Quanto é 7 × 8?",
             ["56",
              "54",
              "48",
              "64"],
             0),

            ("Quanto é 72 ÷ 8?",
             ["9",
              "8",
              "7",
              "10"],
             0),

            ("Quanto é 6 × 4?",
             ["24",
              "20",
              "28",
              "18"],
             0),

            ("Quanto é 100 + 250?",
             ["350",
              "300",
              "450",
              "360"],
             0),

            ("Quanto é 5 × 9?",
             ["45",
              "40",
              "50",
              "35"],
             0),

            ("Quanto é 36 ÷ 6?",
             ["6",
              "5",
              "7",
              "9"],
             0),

            ("Quantas centenas há em 500?",
             ["5",
              "50",
              "10",
              "0"],
             0),

            ("Qual fração representa a metade?",
             ["1/2",
              "1/4",
              "2/3",
              "1/3"],
             0),

            ("Quanto é 3 × 12?",
             ["36",
              "32",
              "30",
              "42"],
             0),

            ("Quanto valem 2 notas de R$ 50?",
             ["R$ 100",
              "R$ 52",
              "R$ 150",
              "R$ 200"],
             0),
        ],

        "4º Ano": [
            ("Quanto é 125 + 275?",
             ["400",
              "390",
              "410",
              "450"],
             0),

            ("Quanto é 600 - 245?",
             ["355",
              "345",
              "365",
              "375"],
             0),

            ("Quanto é 15 × 6?",
             ["90",
              "80",
              "96",
              "75"],
             0),

            ("Quanto é 144 ÷ 12?",
             ["12",
              "14",
              "11",
              "10"],
             0),

            ("Qual é o perímetro de um quadrado de lado 5 cm?",
             ["20 cm",
              "10 cm",
              "25 cm",
              "15 cm"],
             0),

            ("Qual fração representa 3 partes de um todo dividido em 4 partes iguais?",
             ["3/4",
              "4/3",
              "1/4",
              "3/7"],
             0),

            ("Quanto é 1.000 - 250?",
             ["750",
              "650",
              "850",
              "800"],
             0),

            ("Qual é a metade de 1.000?",
             ["500",
              "50",
              "250",
              "1.500"],
             0),

            ("Quantos graus tem um ângulo reto?",
             ["90°",
              "180°",
              "45°",
              "360°"],
             0),

            ("Quanto é 8 × 125?",
             ["1.000",
              "800",
              "1.250",
              "900"],
             0),
        ],

        "5º Ano": [
            ("Quanto é 12 × 12?",
             ["144",
              "124",
              "134",
              "154"],
             0),

            ("Quanto é 225 ÷ 15?",
             ["15",
              "10",
              "20",
              "25"],
             0),

            ("Qual fração é equivalente a 1/2?",
             ["2/4",
              "1/3",
              "2/3",
              "3/5"],
             0),

            ("Quanto é 0,5 + 0,25?",
             ["0,75",
              "0,55",
              "0,30",
              "1,25"],
             0),

            ("Quanto é 10% de 200?",
             ["20",
              "10",
              "2",
              "100"],
             0),

            ("Qual é a área de um retângulo de 6 cm por 4 cm?",
             ["24 cm²",
              "20 cm²",
              "10 cm²",
              "12 cm²"],
             0),

            ("Quanto é 3/4 + 1/4?",
             ["1",
              "4/8",
              "2/4",
              "3/8"],
             0),

            ("Qual é a média entre 6, 8 e 10?",
             ["8",
              "7",
              "9",
              "24"],
             0),

            ("Quanto é 2,5 × 4?",
             ["10",
              "8",
              "12",
              "9"],
             0),

            ("Quanto é 1.500 ÷ 5?",
             ["300",
              "250",
              "350",
              "30"],
             0),
        ],

        "6º Ano": [
            ("Quanto é 3²?",
             ["9",
              "6",
              "8",
              "12"],
             0),

            ("Qual é o MMC de 4 e 6?",
             ["12",
              "24",
              "2",
              "10"],
             0),

            ("Qual é o MDC de 12 e 18?",
             ["6",
              "3",
              "36",
              "2"],
             0),

            ("Qual destes números é primo?",
             ["13",
              "15",
              "21",
              "9"],
             0),

            ("Quanto é 2/3 + 1/3?",
             ["1",
              "3/6",
              "2/9",
              "3/9"],
             0),

            ("Qual é o resultado de 5 + 3 × 2?",
             ["11",
              "16",
              "13",
              "10"],
             0),

            ("Quanto é 4³?",
             ["64",
              "12",
              "16",
              "81"],
             0),

            ("Quanto é 1/2 de 3/4?",
             ["3/8",
              "1/4",
              "5/6",
              "3/6"],
             0),

            ("Qual é o resultado de 0,3 × 0,2?",
             ["0,06",
              "0,6",
              "0,5",
              "0,006"],
             0),

            ("Qual destes números é divisível por 3?",
             ["27",
              "25",
              "31",
              "40"],
             0),
        ],

        "7º Ano": [
            ("Quanto é (−5) + 8?",
             ["3",
              "−3",
              "13",
              "−13"],
             0),

            ("Quanto é (−4) × (−3)?",
             ["12",
              "−12",
              "7",
              "−7"],
             0),

            ("Qual é o valor de x em x + 7 = 15?",
             ["8",
              "7",
              "9",
              "22"],
             0),

            ("Quanto é 15% de 200?",
             ["30",
              "20",
              "25",
              "35"],
             0),

            ("Qual é o valor de x em 3x = 21?",
             ["7",
              "6",
              "8",
              "18"],
             0),

            ("Se 3 canetas custam R$ 6, quanto custam 5 canetas?",
             ["R$ 10",
              "R$ 15",
              "R$ 12",
              "R$ 8"],
             0),

            ("Qual é a razão entre 10 e 5?",
             ["2",
              "5",
              "15",
              "0,5"],
             0),

            ("Quanto é (−7) − (−2)?",
             ["−5",
              "−9",
              "5",
              "9"],
             0),

            ("Quanto é 3 × (4 + 2)?",
             ["18",
              "14",
              "12",
              "20"],
             0),

            ("Qual é o valor de x em 2x − 4 = 10?",
             ["7",
              "3",
              "5",
              "14"],
             0),
        ],

        "8º Ano": [
            ("Qual é o valor de √81?",
             ["9",
              "8",
              "7",
              "11"],
             0),

            ("Qual é o desenvolvimento de (a + b)²?",
             ["a² + 2ab + b²",
              "a² + b²",
              "a² − b²",
              "2a + 2b"],
             0),

            ("Qual é o valor de x em 2x + 4 = 12?",
             ["4",
              "3",
              "5",
              "6"],
             0),

            ("Quanto é 2⁵?",
             ["32",
              "10",
              "16",
              "25"],
             0),

            ("Quanto é 5² − 3²?",
             ["16",
              "4",
              "34",
              "2"],
             0),

            ("No sistema x + y = 10 e x − y = 2, quanto vale x?",
             ["6",
              "4",
              "8",
              "5"],
             0),

            ("Quanto é 3,2 × 10³?",
             ["3.200",
              "320",
              "32",
              "32.000"],
             0),

            ("Qual é o valor de 3a + 2 quando a = 4?",
             ["14",
              "12",
              "10",
              "24"],
             0),

            ("Ao lançar um dado comum, qual é a probabilidade de sair o 6?",
             ["1/6",
              "1/3",
              "1/2",
              "6/1"],
             0),

            ("Qual é a soma dos ângulos internos de um triângulo?",
             ["180°",
              "360°",
              "90°",
              "270°"],
             0),
        ],

        "9º Ano": [
            ("Qual é o valor de √169?",
             ["13",
              "14",
              "12",
              "15"],
             0),

            ("Em um triângulo retângulo com catetos 3 e 4, quanto mede a hipotenusa?",
             ["5",
              "7",
              "6",
              "4,5"],
             0),

            ("Quais são as raízes de x² − 5x + 6 = 0?",
             ["2 e 3",
              "1 e 6",
              "−2 e −3",
              "5 e 6"],
             0),

            ("Fatorando x² − 9, obtemos:",
             ["(x + 3)(x − 3)",
              "(x − 3)²",
              "(x + 9)(x − 1)",
              "(x + 3)²"],
             0),

            ("Qual é o valor de f(3) na função f(x) = 2x + 1?",
             ["7",
              "6",
              "5",
              "9"],
             0),

            ("Qual é o seno de 30°?",
             ["1/2",
              "√3/2",
              "1",
              "√2/2"],
             0),

            ("Qual é o volume de um cubo de aresta 3 cm?",
             ["27 cm³",
              "9 cm³",
              "18 cm³",
              "12 cm³"],
             0),

            ("Qual é o juro simples de R$ 100 a 10% ao mês durante 2 meses?",
             ["R$ 20",
              "R$ 10",
              "R$ 21",
              "R$ 120"],
             0),

            ("Qual é o valor de 10⁻²?",
             ["0,01",
              "−100",
              "0,1",
              "−20"],
             0),

            ("Quanto vale a soma dos ângulos internos de um quadrilátero?",
             ["360°",
              "180°",
              "270°",
              "540°"],
             0),
        ],
    },

}


# ============================================================
# LÍNGUAS
# ============================================================

PERGUNTAS_LINGUAS = {

    "Português": [

        ("Qual é o plural de 'cão'?",
         ["Cães",
          "Cãezes",
          "Cãeses",
          "Cãoes"],
         0),

        ("Qual palavra é um substantivo?",
         ["Casa",
          "Bonito",
          "Correr",
          "Rapidamente"],
         0),

        ("Qual é o contrário de 'alto'?",
         ["Baixo",
          "Grande",
          "Largo",
          "Forte"],
         0),

        ("Qual palavra é um verbo?",
         ["Correr",
          "Casa",
          "Azul",
          "Bonito"],
         0),

        ("Qual é o feminino de 'ator'?",
         ["Atriz",
          "Atoresa",
          "Atora",
          "Atriza"],
         0),

        ("Qual é o plural de 'papel'?",
         ["Papéis",
          "Papeis",
          "Papels",
          "Papéus"],
         0),

        ("Qual palavra é um adjetivo?",
         ["Bonito",
          "Casa",
          "Correr",
          "Ontem"],
         0),

        ("Qual é um sinônimo de 'feliz'?",
         ["Alegre",
          "Triste",
          "Bravo",
          "Cansado"],
         0),

        ("Qual é o contrário de 'rápido'?",
         ["Lento",
          "Forte",
          "Alto",
          "Grande"],
         0),

        ("Qual é o plural de 'flor'?",
         ["Flores",
          "Flors",
          "Florais",
          "Flore"],
         0),
    ],


    "Inglês": [

        ("O que significa 'house'?",
         ["Casa",
          "Carro",
          "Escola",
          "Livro"],
         0),

        ("O que significa 'dog'?",
         ["Cachorro",
          "Gato",
          "Pássaro",
          "Cavalo"],
         0),

        ("Como se diz 'azul' em inglês?",
         ["Blue",
          "Red",
          "Green",
          "Yellow"],
         0),

        ("Como se diz 'obrigado' em inglês?",
         ["Thank you",
          "Goodbye",
          "Hello",
          "Please"],
         0),

        ("O que significa 'book'?",
         ["Livro",
          "Caneta",
          "Mesa",
          "Caderno"],
         0),

        ("Como se diz 'água' em inglês?",
         ["Water",
          "Fire",
          "Earth",
          "Air"],
         0),

        ("O que significa 'school'?",
         ["Escola",
          "Hospital",
          "Casa",
          "Mercado"],
         0),

        ("Como se diz 'vermelho' em inglês?",
         ["Red",
          "Blue",
          "White",
          "Black"],
         0),

        ("O que significa 'friend'?",
         ["Amigo",
          "Irmão",
          "Professor",
          "Pai"],
         0),

        ("Como se diz 'bom dia' em inglês?",
         ["Good morning",
          "Good night",
          "Goodbye",
          "Good afternoon"],
         0),
    ],


    "Latim": [

        ("O que significa 'aqua'?",
         ["Água",
          "Terra",
          "Fogo",
          "Ar"],
         0),

        ("O que significa 'terra'?",
         ["Terra",
          "Água",
          "Casa",
          "Sol"],
         0),

        ("O que significa 'amicus'?",
         ["Amigo",
          "Inimigo",
          "Professor",
          "Rei"],
         0),

        ("O que significa 'vita'?",
         ["Vida",
          "Morte",
          "Casa",
          "Livro"],
         0),

        ("O que significa 'luna'?",
         ["Lua",
          "Sol",
          "Estrela",
          "Terra"],
         0),

        ("O que significa 'sol'?",
         ["Sol",
          "Lua",
          "Céu",
          "Mar"],
         0),

        ("O que significa 'rex'?",
         ["Rei",
          "Soldado",
          "Cidadão",
          "Professor"],
         0),

        ("O que significa 'mater'?",
         ["Mãe",
          "Pai",
          "Filha",
          "Irmã"],
         0),

        ("O que significa 'pater'?",
         ["Pai",
          "Mãe",
          "Irmão",
          "Filho"],
         0),

        ("O que significa 'bonus'?",
         ["Bom",
          "Grande",
          "Rápido",
          "Forte"],
         0),
    ],


    "Espanhol": [

        ("O que significa 'casa'?",
         ["Casa",
          "Carro",
          "Escola",
          "Livro"],
         0),

        ("O que significa 'perro'?",
         ["Cachorro",
          "Gato",
          "Cavalo",
          "Pássaro"],
         0),

        ("Como se diz 'vermelho' em espanhol?",
         ["Rojo",
          "Azul",
          "Verde",
          "Amarillo"],
         0),

        ("O que significa 'agua'?",
         ["Água",
          "Fogo",
          "Terra",
          "Ar"],
         0),

        ("Como se diz 'amigo' em espanhol?",
         ["Amigo",
          "Hermano",
          "Padre",
          "Maestro"],
         0),

        ("O que significa 'escuela'?",
         ["Escola",
          "Casa",
          "Igreja",
          "Mercado"],
         0),

        ("Como se diz 'obrigado' em espanhol?",
         ["Gracias",
          "Hola",
          "Adiós",
          "Buenos días"],
         0),

        ("O que significa 'libro'?",
         ["Livro",
          "Caneta",
          "Mesa",
          "Caderno"],
         0),

        ("Como se diz 'bom dia' em espanhol?",
         ["Buenos días",
          "Buenas noches",
          "Hola",
          "Adiós"],
         0),

        ("O que significa 'feliz'?",
         ["Feliz",
          "Triste",
          "Bravo",
          "Cansado"],
         0),
    ],


    "Italiano": [

        ("O que significa 'casa' em italiano?",
         ["Casa",
          "Carro",
          "Escola",
          "Livro"],
         0),

        ("Como se diz 'obrigado' em italiano?",
         ["Grazie",
          "Ciao",
          "Prego",
          "Buongiorno"],
         0),

        ("O que significa 'ciao'?",
         ["Olá/Tchau",
          "Obrigado",
          "Casa",
          "Amigo"],
         0),

        ("Como se diz 'água' em italiano?",
         ["Acqua",
          "Fuoco",
          "Terra",
          "Aria"],
         0),

        ("O que significa 'amico'?",
         ["Amigo",
          "Pai",
          "Irmão",
          "Professor"],
         0),

        ("Como se diz 'bom dia' em italiano?",
         ["Buongiorno",
          "Buonanotte",
          "Grazie",
          "Ciao"],
         0),

        ("O que significa 'libro'?",
         ["Livro",
          "Casa",
          "Mesa",
          "Escola"],
         0),

        ("Como se diz 'vermelho' em italiano?",
         ["Rosso",
          "Blu",
          "Verde",
          "Giallo"],
         0),

        ("O que significa 'famiglia'?",
         ["Família",
          "Amigo",
          "Escola",
          "Cidade"],
         0),

        ("Como se diz 'sim' em italiano?",
         ["Sì",
          "No",
          "Ciao",
          "Grazie"],
         0),
    ],
}


# ============================================================
# CONFIGURAÇÕES
# ============================================================

TEMPO_INICIAL = 12
TEMPO_EXTRA_RELOGIO = 5

CUSTO_DICA = 10
CUSTO_RELOGIO = 5

TOTAL_PERGUNTAS = 10

TEMPO_RESPOSTA_GRUPO = 3


# ============================================================
# VARIÁVEIS
# ============================================================

modo = None
materia = None
ano = None

pergunta_atual = None

numero_pergunta = 0
pontuacao = 0
moedas = 0

tempo_restante = TEMPO_INICIAL

timer_id = None
proximo_id = None

dica_usada = False
relogio_usado = False
respondida = False

perguntas_usadas = {}

botoes_resposta = []

correta_atual = 0
texto_correto_atual = ""

em_jogo = False

animacao_resposta_id = None
animacao_resposta_estado = False

overlay_resposta = None


# ============================================================
# JANELA
# ============================================================

root = tk.Tk()

root.title(
    "O Super Quiz"
)

root.geometry(
    "1100x700"
)

root.minsize(
    800,
    600
)

root.configure(
    bg="#101522"
)

fullscreen = False


# ============================================================
# FULLSCREEN
# ============================================================

def alternar_fullscreen(event=None):

    global fullscreen

    fullscreen = not fullscreen

    root.attributes(
        "-fullscreen",
        fullscreen
    )


root.bind(
    "<F11>",
    alternar_fullscreen
)


# ============================================================
# ESC VOLTA AO MENU
# ============================================================

def tecla_escape(event=None):

    global timer_id

    if em_jogo:

        pausado = False

        # pausa o relógio enquanto a pergunta está na tela
        if not respondida and timer_id is not None:

            try:
                root.after_cancel(
                    timer_id
                )
            except Exception:
                pass

            timer_id = None

            pausado = True

        sair = messagebox.askyesno(
            "Voltar ao menu",
            "Deseja sair da partida e voltar ao menu?\n"
            "O progresso será perdido.",
            parent=root
        )

        if not sair:

            if pausado:

                timer_id = root.after(
                    1000,
                    atualizar_tempo
                )

            return

    menu_principal()


root.bind(
    "<Escape>",
    tecla_escape
)


# ============================================================
# LIMPAR TELA
# ============================================================

def limpar_tela():

    global timer_id
    global proximo_id
    global animacao_resposta_id
    global overlay_resposta

    if timer_id is not None:

        try:
            root.after_cancel(
                timer_id
            )
        except Exception:
            pass

        timer_id = None

    if proximo_id is not None:

        try:
            root.after_cancel(
                proximo_id
            )
        except Exception:
            pass

        proximo_id = None

    if animacao_resposta_id is not None:

        try:
            root.after_cancel(
                animacao_resposta_id
            )
        except Exception:
            pass

        animacao_resposta_id = None

    if overlay_resposta is not None:

        try:
            overlay_resposta.destroy()
        except Exception:
            pass

        overlay_resposta = None

    for widget in root.winfo_children():

        widget.destroy()


# ============================================================
# BOTÃO PADRÃO
# ============================================================

def com_clique(comando):

    def executar():

        tocar_som("clique")

        comando()

    return executar


def criar_botao(
    parent,
    texto,
    comando,
    largura=20
):

    return tk.Button(
        parent,
        text=texto,
        command=com_clique(comando),
        font=(
            "Arial",
            16,
            "bold"
        ),
        bg="#24304A",
        fg="white",
        activebackground="#35466B",
        activeforeground="white",
        relief="flat",
        bd=0,
        width=largura,
        height=2,
        cursor="hand2"
    )


# ============================================================
# MENU PRINCIPAL
# ============================================================

def menu_principal():

    global modo
    global em_jogo

    limpar_tela()

    parar_musica()

    modo = None

    em_jogo = False

    titulo = tk.Label(
        root,
        text="🎮 O Super Quiz",
        font=(
            "Arial",
            42,
            "bold"
        ),
        bg="#101522",
        fg="#65E6FF"
    )

    titulo.pack(
        pady=(70, 20)
    )

    subtitulo = tk.Label(
        root,
        text="Escolha o modo de jogo",
        font=(
            "Arial",
            20
        ),
        bg="#101522",
        fg="white"
    )

    subtitulo.pack(
        pady=20
    )

    botao_individual = criar_botao(
        root,
        "👤 Modo Individual",
        escolher_materia,
        25
    )

    botao_individual.pack(
        pady=12
    )

    botao_grupo = criar_botao(
        root,
        "👥 Modo Grupo",
        escolher_materia_grupo,
        25
    )

    botao_grupo.pack(
        pady=12
    )


# ============================================================
# ESCOLHER MATÉRIA
# ============================================================

def escolher_materia():

    global modo

    modo = "individual"

    tela_materias()


def escolher_materia_grupo():

    global modo

    modo = "grupo"

    tela_materias()


def tela_materias():

    limpar_tela()

    titulo = tk.Label(
        root,
        text="📚 Escolha a matéria",
        font=(
            "Arial",
            32,
            "bold"
        ),
        bg="#101522",
        fg="white"
    )

    titulo.pack(
        pady=40
    )

    frame = tk.Frame(
        root,
        bg="#101522"
    )

    frame.pack()

    materias = [
        "História",
        "Geografia",
        "Matemática",
        "Línguas"
    ]

    for i, nome in enumerate(
        materias
    ):

        botao = criar_botao(
            frame,
            nome,
            lambda n=nome:
                escolher_materia_nome(n),
            18
        )

        botao.grid(
            row=i // 2,
            column=i % 2,
            padx=15,
            pady=15
        )

    voltar = criar_botao(
        root,
        "⬅ Voltar",
        menu_principal,
        15
    )

    voltar.pack(
        pady=30
    )


def escolher_materia_nome(nome):

    global materia

    materia = nome

    if nome == "Línguas":

        escolher_lingua()

    else:

        escolher_ano()


# ============================================================
# LÍNGUAS
# ============================================================

def escolher_lingua():

    limpar_tela()

    titulo = tk.Label(
        root,
        text="🌎 Escolha a língua",
        font=(
            "Arial",
            32,
            "bold"
        ),
        bg="#101522",
        fg="white"
    )

    titulo.pack(
        pady=40
    )

    frame = tk.Frame(
        root,
        bg="#101522"
    )

    frame.pack()

    linguas = [
        "Português",
        "Inglês",
        "Latim",
        "Espanhol",
        "Italiano"
    ]

    for i, lingua in enumerate(
        linguas
    ):

        botao = criar_botao(
            frame,
            lingua,
            lambda n=lingua:
                escolher_lingua_nome(n),
            18
        )

        botao.grid(
            row=i // 2,
            column=i % 2,
            padx=15,
            pady=15
        )

    voltar = criar_botao(
        root,
        "⬅ Voltar",
        tela_materias,
        15
    )

    voltar.pack(
        pady=30
    )


def escolher_lingua_nome(nome):

    global materia
    global ano

    materia = nome

    ano = "Língua"

    iniciar_jogo()


# ============================================================
# ESCOLHER ANO
# ============================================================

def escolher_ano():

    limpar_tela()

    titulo = tk.Label(
        root,
        text="🎓 Escolha o ano",
        font=(
            "Arial",
            32,
            "bold"
        ),
        bg="#101522",
        fg="white"
    )

    titulo.pack(
        pady=35
    )

    frame = tk.Frame(
        root,
        bg="#101522"
    )

    frame.pack()

    anos = [
        "1º Ano",
        "2º Ano",
        "3º Ano",
        "4º Ano",
        "5º Ano",
        "6º Ano",
        "7º Ano",
        "8º Ano",
        "9º Ano"
    ]

    for i, nome in enumerate(
        anos
    ):

        botao = criar_botao(
            frame,
            nome,
            lambda n=nome:
                escolher_ano_nome(n),
            15
        )

        botao.grid(
            row=i // 3,
            column=i % 3,
            padx=10,
            pady=10
        )

    voltar = criar_botao(
        root,
        "⬅ Voltar",
        tela_materias,
        15
    )

    voltar.pack(
        pady=25
    )


def escolher_ano_nome(nome):

    global ano

    ano = nome

    iniciar_jogo()


# ============================================================
# INICIAR JOGO
# ============================================================

def iniciar_jogo():

    global numero_pergunta
    global pontuacao
    global em_jogo

    numero_pergunta = 0
    pontuacao = 0

    em_jogo = True

    # cada partida começa com todas as perguntas disponíveis
    perguntas_usadas[
        (materia, ano)
    ] = []

    tocar_som("comecar")

    mostrar_pergunta()


# ============================================================
# PEGAR BANCO DE PERGUNTAS
# ============================================================

def obter_perguntas():

    if materia == "Línguas":

        return PERGUNTAS_LINGUAS.get(
            materia,
            []
        )

    return PERGUNTAS.get(
        materia,
        {}
    ).get(
        ano,
        []
    )


# ============================================================
# PEGAR PERGUNTA SEM REPETIR
# ============================================================

def pegar_pergunta():

    chave = (
        materia,
        ano
    )

    banco = obter_perguntas()

    if not banco:

        return (
            "Pergunta de teste",
            [
                "Alternativa A",
                "Alternativa B",
                "Alternativa C",
                "Alternativa D"
            ],
            0
        )

    if chave not in perguntas_usadas:

        perguntas_usadas[chave] = []

    disponiveis = [
        i
        for i in range(
            len(banco)
        )
        if i not in perguntas_usadas[chave]
    ]

    if not disponiveis:

        perguntas_usadas[chave] = []

        disponiveis = list(
            range(
                len(banco)
            )
        )

    indice = random.choice(
        disponiveis
    )

    perguntas_usadas[chave].append(
        indice
    )

    return banco[indice]


# ============================================================
# MOSTRAR PERGUNTA
# ============================================================

def mostrar_pergunta():

    global pergunta_atual
    global numero_pergunta
    global tempo_restante
    global dica_usada
    global relogio_usado
    global respondida
    global botoes_resposta
    global correta_atual
    global texto_correto_atual

    limpar_tela()

    if numero_pergunta >= TOTAL_PERGUNTAS:

        finalizar_jogo()

        return

    dica_usada = False
    relogio_usado = False
    respondida = False

    tempo_restante = TEMPO_INICIAL

    pergunta_atual = pegar_pergunta()

    texto_pergunta = pergunta_atual[0]
    alternativas = pergunta_atual[1]
    indice_correto_original = pergunta_atual[2]

    alternativas_com_indices = list(
        enumerate(alternativas)
    )

    random.shuffle(
        alternativas_com_indices
    )

    alternativas_novas = [
        item[1]
        for item in alternativas_com_indices
    ]

    correta_atual = next(
        i
        for i, item in enumerate(
            alternativas_com_indices
        )
        if item[0] == indice_correto_original
    )

    texto_correto_atual = alternativas_novas[
        correta_atual
    ]

    # ========================================================
    # TOPO
    # ========================================================

    topo = tk.Frame(
        root,
        bg="#101522"
    )

    topo.pack(
        fill="x",
        padx=25,
        pady=15
    )

    label_pergunta = tk.Label(
        topo,
        text=(
            f"Pergunta "
            f"{numero_pergunta + 1}"
            f"/{TOTAL_PERGUNTAS}"
        ),
        font=(
            "Arial",
            18,
            "bold"
        ),
        bg="#101522",
        fg="white"
    )

    label_pergunta.pack(
        side="left"
    )

    label_materia = tk.Label(
        topo,
        text=f"{materia} • {ano}",
        font=(
            "Arial",
            18,
            "bold"
        ),
        bg="#101522",
        fg="#A9C7FF"
    )

    label_materia.pack(
        side="left",
        padx=30
    )

    label_moedas = tk.Label(
        topo,
        text=f"🪙 {moedas}",
        font=(
            "Arial",
            18,
            "bold"
        ),
        bg="#101522",
        fg="#FFD54A"
    )

    label_moedas.pack(
        side="right"
    )

    # ========================================================
    # TIMER
    # ========================================================

    label_tempo = tk.Label(
        root,
        text=f"⏱ {tempo_restante}s",
        font=(
            "Arial",
            30,
            "bold"
        ),
        bg="#101522",
        fg="#55DD77"
    )

    label_tempo.pack(
        pady=5
    )

    root.label_tempo = label_tempo

    # ========================================================
    # PERGUNTA
    # ========================================================

    label_questao = tk.Label(
        root,
        text=texto_pergunta,
        font=(
            "Arial",
            24,
            "bold"
        ),
        bg="#101522",
        fg="white",
        wraplength=900,
        justify="center"
    )

    label_questao.pack(
        pady=25
    )

    # ========================================================
    # BOTÕES
    # ========================================================

    frame_respostas = tk.Frame(
        root,
        bg="#101522"
    )

    frame_respostas.pack(
        fill="x",
        padx=100
    )

    botoes_resposta = []

    letras = [
        "A",
        "B",
        "C",
        "D"
    ]

    for i in range(4):

        botao = tk.Button(
            frame_respostas,
            text=(
                f"{letras[i]}) "
                f"{alternativas_novas[i]}"
            ),
            command=lambda x=i:
                responder(x),
            font=(
                "Arial",
                17,
                "bold"
            ),
            bg="#24304A",
            fg="white",
            activebackground="#35466B",
            activeforeground="white",
            relief="flat",
            bd=0,
            height=2,
            cursor="hand2"
        )

        botao.grid(
            row=i // 2,
            column=i % 2,
            sticky="ew",
            padx=8,
            pady=8
        )

        botoes_resposta.append(
            botao
        )

    frame_respostas.grid_columnconfigure(
        0,
        weight=1
    )

    frame_respostas.grid_columnconfigure(
        1,
        weight=1
    )

    # ========================================================
    # FEEDBACK
    # ========================================================

    label_feedback = tk.Label(
        root,
        text="",
        font=(
            "Arial",
            18,
            "bold"
        ),
        bg="#101522",
        fg="white"
    )

    label_feedback.pack(
        pady=12
    )

    root.label_feedback = label_feedback

    # ========================================================
    # AJUDAS INDIVIDUAIS
    # ========================================================

    if modo == "individual":

        frame_ajuda = tk.Frame(
            root,
            bg="#101522"
        )

        frame_ajuda.pack(
            pady=5
        )

        botao_dica = tk.Button(
            frame_ajuda,
            text="🔦 Dica - 10 🪙",
            command=usar_dica,
            font=(
                "Arial",
                14,
                "bold"
            ),
            bg="#7A5C00",
            fg="white",
            activebackground="#9B7600",
            relief="flat",
            width=18,
            height=2
        )

        botao_dica.grid(
            row=0,
            column=0,
            padx=8
        )

        botao_relogio = tk.Button(
            frame_ajuda,
            text="⏰ +5 segundos - 5 🪙",
            command=usar_relogio,
            font=(
                "Arial",
                14,
                "bold"
            ),
            bg="#155B7A",
            fg="white",
            activebackground="#1D789F",
            relief="flat",
            width=20,
            height=2
        )

        botao_relogio.grid(
            row=0,
            column=1,
            padx=8
        )

        root.botao_dica = botao_dica

        root.botao_relogio = botao_relogio

    # ========================================================
    # MODO GRUPO
    # ========================================================

    else:

        for botao in botoes_resposta:

            botao.config(
                state="disabled",
                cursor="arrow"
            )

    # ========================================================
    # MÚSICA
    # ========================================================

    iniciar_musica()

    atualizar_tempo()


# ============================================================
# ATUALIZAR TEMPO
# ============================================================

def atualizar_tempo():

    global tempo_restante
    global timer_id

    if respondida:

        return

    if tempo_restante <= 0:

        tempo_esgotado()

        return

    if tempo_restante <= 4:

        root.label_tempo.config(
            fg="#FF4D4D"
        )

    elif tempo_restante <= 7:

        root.label_tempo.config(
            fg="#FFD54A"
        )

    else:

        root.label_tempo.config(
            fg="#55DD77"
        )

    root.label_tempo.config(
        text=f"⏱ {tempo_restante}s"
    )

    if tempo_restante <= 3:

        tocar_som("tick")

    tempo_restante -= 1

    timer_id = root.after(
        1000,
        atualizar_tempo
    )


# ============================================================
# RESPONDER
# ============================================================

def responder(indice):

    global pontuacao
    global moedas
    global respondida
    global numero_pergunta
    global proximo_id

    if respondida:

        return

    respondida = True

    for botao in botoes_resposta:

        botao.config(
            state="disabled"
        )

    texto_correto = texto_correto_atual

    if indice == correta_atual:

        pontuacao += 1

        moedas += 1

        botoes_resposta[
            indice
        ].config(
            bg="#168A3A",
            fg="white"
        )

        tocar_som_acerto()

        mostrar_resposta_no_centro(
            texto_correto
        )

        numero_pergunta += 1

        proximo_id = root.after(
            1800,
            mostrar_pergunta
        )

    else:

        botoes_resposta[
            indice
        ].config(
            bg="#B52B2B",
            fg="white"
        )

        botoes_resposta[
            correta_atual
        ].config(
            bg="#168A3A",
            fg="white"
        )

        root.label_feedback.config(
            text=(
                "✗ ERRADO!\n"
                f"Resposta correta: "
                f"{texto_correto}"
            ),
            fg="#FF6666"
        )

        tocar_som("erro")

        numero_pergunta += 1

        proximo_id = root.after(
            1400,
            mostrar_pergunta
        )


# ============================================================
# TEMPO ESGOTADO
# ============================================================

def tempo_esgotado():

    global respondida
    global numero_pergunta
    global proximo_id

    if respondida:

        return

    respondida = True

    for botao in botoes_resposta:

        botao.config(
            state="disabled"
        )

    if modo == "grupo":

        revelar_resposta_grupo()

    else:

        texto_correto = texto_correto_atual

        botoes_resposta[
            correta_atual
        ].config(
            bg="#168A3A",
            fg="white"
        )

        root.label_feedback.config(
            text=(
                "⏰ TEMPO ESGOTADO!\n"
                f"Resposta correta: "
                f"{texto_correto}"
            ),
            fg="#FFD54A"
        )

        numero_pergunta += 1

        tocar_som("esgotado")

        proximo_id = root.after(
            1800,
            mostrar_pergunta
        )


# ============================================================
# RESPOSTA DO MODO GRUPO
# ============================================================

def revelar_resposta_grupo():

    global numero_pergunta

    tocar_som_acerto()

    texto_resposta = texto_correto_atual

    botoes_resposta[
        correta_atual
    ].config(
        bg="#168A3A",
        fg="white",
        font=(
            "Arial",
            23,
            "bold"
        ),
        height=2
    )

    for botao in botoes_resposta:

        botao.config(
            state="disabled"
        )

    mostrar_resposta_no_centro(
        texto_resposta,
        texto_personalizado=(
            'A resposta certa é:\n\n'
            f'"{texto_resposta}"'
        )
    )

    numero_pergunta += 1

    agendar_proxima_pergunta(
        TEMPO_RESPOSTA_GRUPO * 1000
    )


# ============================================================
# MOSTRAR RESPOSTA NO CENTRO
# ============================================================

def mostrar_resposta_no_centro(
    texto_resposta,
    texto_personalizado=None
):

    global overlay_resposta

    if overlay_resposta is not None:

        try:
            overlay_resposta.destroy()
        except Exception:
            pass

    overlay_resposta = tk.Frame(
        root,
        bg="#101522"
    )

    overlay_resposta.place(
        relx=0.5,
        rely=0.50,
        anchor="center",
        relwidth=0.90,
        relheight=0.50
    )

    texto = (
        texto_personalizado
        if texto_personalizado
        else (
            "✓ CORRETO!\n\n"
            f"{texto_resposta}"
        )
    )

    label = tk.Label(
        overlay_resposta,
        text=texto,
        font=(
            "Arial",
            38,
            "bold"
        ),
        fg="#65E86A",
        bg="#101522",
        justify="center"
    )

    label.pack(
        expand=True
    )

    overlay_resposta.label = label

    piscar_resposta_correta()


# ============================================================
# PISCAR RESPOSTA
# ============================================================

def piscar_resposta_correta():

    global animacao_resposta_id
    global animacao_resposta_estado

    if overlay_resposta is None:

        return

    try:

        animacao_resposta_estado = (
            not animacao_resposta_estado
        )

        if animacao_resposta_estado:

            overlay_resposta.config(
                bg="#103A20"
            )

            overlay_resposta.label.config(
                fg="#00FF44",
                bg="#103A20"
            )

        else:

            overlay_resposta.config(
                bg="#101522"
            )

            overlay_resposta.label.config(
                fg="#65E86A",
                bg="#101522"
            )

        animacao_resposta_id = root.after(
            180,
            piscar_resposta_correta
        )

    except Exception:

        pass


# ============================================================
# AGENDAR PRÓXIMA
# ============================================================

def agendar_proxima_pergunta(
    tempo
):

    global proximo_id

    proximo_id = root.after(
        tempo,
        mostrar_pergunta
    )


# ============================================================
# DICA
# ============================================================

def usar_dica():

    global moedas
    global dica_usada

    if respondida or dica_usada:

        return

    if moedas < CUSTO_DICA:

        root.label_feedback.config(
            text="Você não tem moedas suficientes!",
            fg="#FF6666"
        )

        return

    moedas -= CUSTO_DICA

    dica_usada = True

    tocar_som("dica")

    root.botao_dica.config(
        state="disabled",
        cursor="arrow"
    )

    erradas = [
        i
        for i in range(4)
        if i != correta_atual
    ]

    eliminar = random.choice(
        erradas
    )

    botoes_resposta[
        eliminar
    ].config(
        state="disabled",
        bg="#161C29",
        fg="#555B68",
        text="❌ Eliminada"
    )

    root.label_feedback.config(
        text="🔦 Dica usada!",
        fg="#FFD54A"
    )


# ============================================================
# +5 SEGUNDOS
# ============================================================

def usar_relogio():

    global moedas
    global relogio_usado
    global tempo_restante

    if respondida or relogio_usado:

        return

    if moedas < CUSTO_RELOGIO:

        root.label_feedback.config(
            text="Você não tem moedas suficientes!",
            fg="#FF6666"
        )

        return

    moedas -= CUSTO_RELOGIO

    relogio_usado = True

    tempo_restante += TEMPO_EXTRA_RELOGIO

    tocar_som("relogio")

    root.botao_relogio.config(
        state="disabled",
        cursor="arrow"
    )

    root.label_tempo.config(
        text=f"⏱ {tempo_restante}s",
        fg="#55DD77"
    )

    root.label_feedback.config(
        text="⏰ +5 segundos!",
        fg="#55DD77"
    )


# ============================================================
# FINALIZAR JOGO
# ============================================================

def finalizar_jogo():

    global em_jogo

    limpar_tela()

    em_jogo = False

    parar_musica()

    if modo == "grupo":

        texto_final = (
            "Acabaram as perguntas!\n\n"
            "Parabéns a todos os grupos! 🎉"
        )

        tocar_som("vitoria")

    else:

        texto_final = (
            f"Pontuação: "
            f"{pontuacao}/{TOTAL_PERGUNTAS}\n\n"
            f"🪙 Moedas: {moedas}"
        )

        if pontuacao >= TOTAL_PERGUNTAS / 2:

            tocar_som("vitoria")

        else:

            tocar_som("fim")

    titulo = tk.Label(
        root,
        text="🏆 Fim do jogo!",
        font=(
            "Arial",
            38,
            "bold"
        ),
        bg="#101522",
        fg="#FFD54A"
    )

    titulo.pack(
        pady=50
    )

    resultado = tk.Label(
        root,
        text=texto_final,
        font=(
            "Arial",
            25,
            "bold"
        ),
        bg="#101522",
        fg="white",
        justify="center"
    )

    resultado.pack(
        pady=20
    )

    jogar_novamente = criar_botao(
        root,
        "🔄 Jogar novamente",
        iniciar_jogo,
        22
    )

    jogar_novamente.pack(
        pady=10
    )

    menu = criar_botao(
        root,
        "🏠 Menu principal",
        menu_principal,
        22
    )

    menu.pack(
        pady=10
    )


# ============================================================
# INICIAR
# ============================================================

menu_principal()

root.mainloop()
