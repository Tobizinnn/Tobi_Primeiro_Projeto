import os
import wave
import numpy as np

PASTA = "/home/claude/quiz/sons"
os.makedirs(PASTA, exist_ok=True)
RNG = np.random.default_rng(7)


def salvar(nome, dados, sr, pico=0.85):
    dados = np.asarray(dados, dtype=np.float64)
    m = np.max(np.abs(dados))
    if m > 0:
        dados = dados / m * pico
    pcm = (np.clip(dados, -1, 1) * 32767).astype(np.int16)
    with wave.open(os.path.join(PASTA, nome), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def midi(n):
    return 440.0 * 2 ** ((n - 69) / 12.0)


def eixo(dur, sr):
    return np.arange(int(dur * sr)) / sr


def tom(freq, dur, sr, harm=(1.0, 0.4, 0.2), decay=6.0, ataque=0.004, vol=1.0):
    t = eixo(dur, sr)
    onda = sum(a * np.sin(2 * np.pi * freq * (k + 1) * t) for k, a in enumerate(harm))
    env = np.exp(-decay * t) * np.minimum(1, t / ataque) * np.minimum(1, (dur - t) / 0.012)
    return vol * onda * env / sum(harm)


def colocar(buf, sinal, inicio, sr, vol=1.0):
    i = int(inicio * sr)
    f = min(len(buf), i + len(sinal))
    if i < len(buf):
        buf[i:f] += vol * sinal[: f - i]


# ============================================================
# EFEITOS SONOROS
# ============================================================

SR = 44100


def fx_acerto():
    b = np.zeros(int(0.9 * SR))
    for i, (n, d) in enumerate([(72, 0.25), (76, 0.25), (79, 0.25), (84, 0.6)]):
        colocar(b, tom(midi(n), d, SR, (1, 0.3, 0.15), 7), i * 0.07, SR)
    return b


def fx_erro():
    b = np.zeros(int(0.7 * SR))
    for ini, f, d in [(0.0, 196.0, 0.24), (0.2, 147.0, 0.4)]:
        t = eixo(d, SR)
        onda = sum(np.sin(2 * np.pi * f * k * t) / (k * k) * (1 if (k // 2) % 2 == 0 else -1)
                   for k in (1, 3, 5, 7))
        vib = 1 + 0.02 * np.sin(2 * np.pi * 9 * t)
        onda = onda * vib
        env = np.exp(-3.5 * t) * np.minimum(1, t / 0.005) * np.minimum(1, (d - t) / 0.02)
        colocar(b, onda * env, ini, SR)
    return b


def fx_esgotado():
    b = np.zeros(int(1.2 * SR))
    notas = [(64, 0.2), (62, 0.2), (60, 0.2), (55, 0.5)]
    ini = 0.0
    for n, d in notas:
        t = eixo(d, SR)
        f = midi(n) * (1 - 0.04 * t / d)
        fase = 2 * np.pi * np.cumsum(f) / SR
        onda = sum(np.sin(fase * k) / k for k in (1, 2, 3, 4, 5))
        env = np.minimum(1, t / 0.01) * np.exp(-2.2 * t) * np.minimum(1, (d - t) / 0.02)
        colocar(b, onda * env, ini, SR)
        ini += d
    return b


def fx_clique():
    return tom(900, 0.05, SR, (1, 0.3), 70, 0.002, 0.8)


def fx_tick():
    return tom(1400, 0.06, SR, (1, 0.5), 60, 0.001)


def fx_dica():
    d = 0.4
    t = eixo(d, SR)
    f = 600 * (1800 / 600) ** (t / d)
    fase = 2 * np.pi * np.cumsum(f) / SR
    varre = np.sin(fase) * np.sin(np.pi * t / d) ** 0.7
    b = np.zeros(int(0.8 * SR))
    colocar(b, varre * 0.7, 0, SR)
    for i, n in enumerate([96, 100, 103]):
        colocar(b, tom(midi(n), 0.3, SR, (1, 0.2), 14), 0.22 + i * 0.07, SR, 0.5)
    return b


def fx_relogio():
    b = np.zeros(int(0.7 * SR))
    colocar(b, tom(880.0, 0.35, SR, (1, 0.5, 0.25), 9), 0.0, SR)
    colocar(b, tom(1318.5, 0.45, SR, (1, 0.5, 0.25), 8), 0.12, SR)
    return b


def fx_comecar():
    b = np.zeros(int(0.9 * SR))
    for i, (n, d) in enumerate([(67, 0.3), (72, 0.3), (76, 0.55)]):
        colocar(b, tom(midi(n), d, SR, (1, 0.45, 0.2), 6), i * 0.09, SR)
    return b


def fx_vitoria():
    b = np.zeros(int(2.2 * SR))
    harm = (1, 0.5, 0.33, 0.25, 0.2)
    for ini, n, d in [(0.0, 72, 0.12), (0.14, 72, 0.12), (0.28, 72, 0.12), (0.42, 76, 0.2)]:
        colocar(b, tom(midi(n), d, SR, harm, 3), ini, SR)
    for n in (60, 64, 67, 72, 79):
        colocar(b, tom(midi(n), 1.5, SR, harm, 2.2), 0.62, SR, 0.8)
    return b


def fx_fim():
    b = np.zeros(int(2.0 * SR))
    harm = (1, 0.4, 0.2)
    colocar(b, tom(midi(67), 0.5, SR, harm, 4), 0.0, SR)
    colocar(b, tom(midi(64), 0.5, SR, harm, 4), 0.25, SR)
    for n in (60, 64, 67):
        colocar(b, tom(midi(n), 1.3, SR, harm, 2.5), 0.5, SR, 0.8)
    return b


EFEITOS = {
    "acerto": (fx_acerto, 0.85),
    "erro": (fx_erro, 0.85),
    "esgotado": (fx_esgotado, 0.85),
    "clique": (fx_clique, 0.55),
    "tick": (fx_tick, 0.55),
    "dica": (fx_dica, 0.8),
    "relogio": (fx_relogio, 0.8),
    "comecar": (fx_comecar, 0.8),
    "vitoria": (fx_vitoria, 0.9),
    "fim": (fx_fim, 0.8),
}

for nome, (func, pico) in EFEITOS.items():
    salvar(nome + ".wav", func(), SR, pico)


# ============================================================
# MÚSICA DE FUNDO (loop de 16 compassos, alegre e leve)
# ============================================================

MSR = 32000
BPM = 104
BEAT = 60.0 / BPM
OITAVO = BEAT / 2
COMPASSO = 4 * BEAT
N_COMP = 16
TOTAL = N_COMP * COMPASSO
N = int(TOTAL * MSR)
CAUDA = int(3 * MSR)

ACORDES = ["C", "Am", "F", "G", "C", "Am", "F", "G",
           "F", "G", "Em", "Am", "F", "G", "C", "C"]
BAIXO = {"C": 48, "Am": 45, "F": 53, "G": 55, "Em": 52}
VOZES = {"C": [60, 64, 67], "Am": [57, 60, 64], "F": [60, 65, 69],
         "G": [59, 62, 67], "Em": [59, 64, 67]}

X = None
MELODIA = [
    [76, X, 79, 76, X, 74, 72, X],
    [72, X, 76, 72, X, 69, 72, X],
    [77, X, 72, 69, X, 72, 77, X],
    [74, X, 71, 74, X, 79, 74, X],
    [79, X, 76, 79, 81, 79, 76, X],
    [81, X, 76, 72, X, 76, 81, X],
    [77, 76, 74, 72, X, 74, 77, X],
    [79, X, 74, 71, X, 74, 67, X],
    [72, X, 77, X, 81, 77, 72, X],
    [74, X, 79, X, 83, 79, 74, X],
    [76, X, 79, 76, X, 71, 76, X],
    [72, X, 76, 81, X, 76, 72, X],
    [77, X, 81, 77, X, 72, 77, X],
    [79, X, 74, 71, X, 74, 79, X],
    [76, X, 79, 84, X, 79, 76, X],
    [72, X, 76, X, 79, 76, 72, X],
]


def nova():
    return np.zeros(N + CAUDA)


def dobrar(buf):
    loop = buf[:N].copy()
    resto = buf[N:]
    loop[: len(resto)] += resto
    return loop


pad = nova()
baixo = nova()
stab = nova()
mel = nova()
perc = nova()


def chimbal(vol):
    d = 0.06
    r = RNG.normal(size=int(d * MSR))
    r = np.diff(r, prepend=0)
    t = eixo(d, MSR)
    return vol * r * np.exp(-70 * t)


def bumbo():
    d = 0.25
    t = eixo(d, MSR)
    f = 45 + 80 * np.exp(-30 * t)
    fase = 2 * np.pi * np.cumsum(f) / MSR
    return np.sin(fase) * np.exp(-14 * t) * np.minimum(1, t / 0.003)


def palma():
    d = 0.12
    r = RNG.normal(size=int(d * MSR))
    r = np.convolve(np.diff(r, prepend=0), np.ones(3) / 3, mode="same")
    t = eixo(d, MSR)
    return r * np.exp(-34 * t)


for c in range(N_COMP):
    ini = c * COMPASSO
    acorde = ACORDES[c]

    # base suave (pad)
    for n in VOZES[acorde]:
        d = COMPASSO + 0.35
        t = eixo(d, MSR)
        env = np.minimum(1, t / 0.22) * np.minimum(1, (d - t) / 0.3)
        onda = np.sin(2 * np.pi * midi(n) * t) + 0.3 * np.sin(2 * np.pi * midi(n) * 2 * t)
        colocar(pad, onda * env, ini, MSR, 0.10)

    # baixo
    raiz = BAIXO[acorde]
    for slot, nota in [(0, raiz), (3, raiz), (4, raiz + 7), (6, raiz)]:
        colocar(baixo, tom(midi(nota), 0.42, MSR, (1, 0.35, 0.1), 4.5, 0.006), ini + slot * OITAVO, MSR, 0.34)

    # acordes marcando o contratempo
    for slot in (3, 7):
        for n in VOZES[acorde]:
            colocar(stab, tom(midi(n + 12), 0.3, MSR, (1, 0.3, 0.1), 9), ini + slot * OITAVO, MSR, 0.10)

    # melodia
    for slot, nota in enumerate(MELODIA[c]):
        if nota is not None:
            colocar(mel, tom(midi(nota), 0.55, MSR, (1, 0.5, 0.25, 0.12), 6.5, 0.003), ini + slot * OITAVO, MSR, 0.30)

    # percussão leve
    for slot in range(8):
        colocar(perc, chimbal(0.06 if slot % 2 == 0 else 0.10), ini + slot * OITAVO, MSR)
    for slot in (0, 4):
        colocar(perc, bumbo(), ini + slot * OITAVO, MSR, 0.30)
    for slot in (2, 6):
        colocar(perc, palma(), ini + slot * OITAVO, MSR, 0.12)

# eco curto na melodia, pra dar "espaço"
atraso = int(0.75 * BEAT * MSR)
eco = np.zeros_like(mel)
eco[atraso:] = mel[:-atraso] * 0.28
mel = mel + eco

musica = dobrar(pad + baixo + stab + mel + perc)
# suaviza possíveis estalos nas pontas do loop
musica = musica - np.mean(musica)
salvar("musica_fundo.wav", musica, MSR, 0.85)

print("OK:", sorted(os.listdir(PASTA)))
